# 1.8.9
**New Eaglercraft 1.8.9 Client! Reborn after old 1.8.9 got DMCA'd :(**





Creator of this version of Eaglercraft: [@AR-DEV-1](https://github.com/AR-DEV-1) 


Thank you very much for your great work <3
